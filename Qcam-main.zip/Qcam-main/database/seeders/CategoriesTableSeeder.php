<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('categories')->insert([
        	['name'=>'Camera','slug'=>'camera'],
        	['name'=>'Headphones','slug'=>'headphones'],
        	['name'=>'Smartphones','slug'=>'smartphones'],
            ['name'=>'Sport gadgets','slug'=>'sport_gadgets']
        ]);
    }
}
