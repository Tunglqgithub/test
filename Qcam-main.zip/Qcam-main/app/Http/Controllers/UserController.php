<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Auth;
use Socialite;
use App\Http\Requests\CreateUserSignUpRequest;
use App\Http\Requests\CreateSignInRequest;
use App\Http\Requests\CreateUserUpdateRequest;
use App\Http\Requests\CreateChangePasswordRequest;
use App\Bill;
use App\BillDetail;
use App\Product;
use App\Comment;
use App\Models\Order;

class UserController extends Controller
{
    
     function __construct()
    {
        if(Auth::check()){
                view()->share('nguoidung',Auth::user());
        }
    }

    public function userProfile()
   
    {
        if(Auth::user()) {
            $orders = Order::where('user_id',Auth::id())->paginate(5);
            $total = Order::where('user_id',Auth::id())->count();
           return view('page.profile',compact('orders','total')); 
        }
        else {
            return redirect('index');
        }
        
    }

    public function changePasswordShow()
    {
        return view('page.users.password');
    }

    public function previewCart()
    {
        if (Auth::user()) {
            $id = Auth::user()->id;
            $bills = Bill::withTrashed()->where('user_id',$id)->paginate(10);
            $billdetails = BillDetail::all();
            return view('page.users.previewcart',compact('bills','billdetails'));
        }
        return redirect('index');
    }

    public function login(Request $request)
    {
        $Email = $request->email;
        $Password = $request->password;
        // dd($Email);
        if(Auth::attempt(['email' => $Email, 'password' => $Password])) {
            return redirect('/')->with('flash_message','Đăng nhập thành công');
        }
        return redirect()->back()->with('flash_message','Tài khoản đăng nhập của bạn không đúng');
    }
    // public function login(CreateSignInRequest $request)
    // {
    //     $Email = $request->Email;
    //     $Password = ($request->Password);
    //     dd($Email);
    //     if(Auth::attempt(['email' => $Email, 'password' => $Password])) {
    //         return redirect('/')->with('flash_message','Đăng nhập thành công');
    //     }
    //     return redirect()->back()->with('flash_message','Tài khoản đăng nhập của bạn không đúng');
    // }

    public function logout()
    {
    	Auth::logout();
  		return redirect('/');
    }

    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }
   
    public function handleGoogleCallback()
    {
        try {
  
            $user = Socialite::driver('google')->user();
   
            $finduser = User::where('google_id', $user->id)->first();
   
            if($finduser){
   
                Auth::login($finduser);
  
                return redirect('/');
   
            }else{
                $newUser = User::create([
                    'name' => $user->name,
                    'email' => $user->email,
                    'google_id'=> $user->id
                ]);
  
                Auth::login($newUser);
   
                return redirect()->back();
            }
  
        } catch (Exception $e) {
            return redirect('auth/google');
        }
    }

    public function userUpdate(CreateUserUpdateRequest $request,$id)
    {
    	
        $user = User::find($id);  
        $user->name = $request->name;
        $user->address = $request->address;
        $user->phone = $request->phone;
        $user->gender = $request->gender;
        $user->save();
        return redirect('user/'.$id)->with('flash_message','Sửa thông tin thành công');
    }

    public function changePassword(CreateChangePasswordRequest $request,$id)
    {
        $user=User::find($id);
        $user->password = Hash::make($request->password); 
        $user->save();
        return redirect('user/changePassword/'.$id)->with('flash_message','Đổi mật khẩu thành công');
    }

    public function signup(Request $request)
    {
        $data = $request->all();
        // dd($data);
        $data['password'] = Hash::make($data['password']);
        $user = User::create($data);
        Auth::login($user);
        return redirect('/')->with('flash_message','Đăng ký thành công');
        // if(Auth::attempt(['email' => $data['email'], 'password' => $data['password']])) {
        //     return redirect('/')->with('flash_message','Đăng ký thành công');
        // }
        // return redirect('index')->with('flash_message','Đã đăng ký thành công, xin mời đăng nhập !');
    }
    
    public function forgetPassword()
    {
        if(!Auth::user()) {
           return view('auth.passwords.email'); 
        }
        return redirect('index');
        
    }

    public function comment(Request $request,$id)
    {
        $product = Product::find($id);
        $comment = new Comment;
        $comment->product_id = $id;
        $comment->user_id = Auth::id();
        $comment->content = $request->comment;
        $comment->save();
        $comment->name = Auth::user()->name;
        $comment->is_admin = Auth::user()->is_admin;
        return $comment;
    }

    public function deleteComment(Request $request,$id)
    {
        $comment = Comment::findOrFail($id);
        $comment->delete();
        $proId = $request->proId;
        $comment = Comment::where('product_id',$proId)->get();
        return $comment;
    }

    public function exportBill($id)
    {
        $bill = Bill::withTrashed()->findOrFail($id);
        $billDetails = $bill->bill_details;
        $billData  = "";
        $billData .= '<p>Mã bill:'.$bill->id.'| Ngày đặt: '.$bill->created_at.'
                     | Tổng tiền: '.$bill->total.' | Payment: '.$bill->payment.' </p>';
        $billData .= '<p>Ghi chú:'.$bill->note.'</p>';             
        $billData .= '<p>Tên người đặt:'.$bill->name.'</p>';
        $billData .= '<p> Địa chỉ nhận hàng: '.$bill->address.'</p>';
        $billData .= '<p> Phone: '.$bill->phone.'</p>';
        $billData .= '<table style="border: 1px solid black; font-family: "Times New Roman", Times, serif;" > 
                        <tr>
                        <th style="border: 1px solid black; "> Bánh </th>
                        <th style="border: 1px solid black; "> Số lượng </th>
                        <th style="border: 1px solid black; "> Đơn giá </th>
                        <th style="border: 1px solid black; "> Thành tiền </th>
                        </tr>';
        foreach($billDetails as $billDetail){
            $billData .= '<tr>
                        <td style="border: 1px solid black">'.$billDetail->product->name.'</td>
                        <td style="border: 1px solid black">'.$billDetail->quantity.'</td>
                        <td style="border: 1px solid black">'.$billDetail->unit_price.'</td>
                        <td style="border: 1px solid black">'.$billDetail->quantity*$billDetail->unit_price.'</td>
                        </tr>';
        }
        $billData .= '</table>';
        header('Content-Type: application/xls');
        header('Content-Disposition: attachment; filename=bill.xls');
        echo $billData;
    }
}
